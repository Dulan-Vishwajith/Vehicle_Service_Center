<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$isLoggedIn = isset($_SESSION["user_id"]);

/*
|--------------------------------------------------------------------------
| User Role
|--------------------------------------------------------------------------
| Role 2 = Service Assistant
*/
$userRole = (int) ($_SESSION["role_id"] ?? 0);


/*
|--------------------------------------------------------------------------
| Project Root / Base URL
|--------------------------------------------------------------------------
| Automatically detects whether VEYRO is running:
|
| Local:
| http://localhost/Vehicle_Service_Center/
|
| Hosting:
| https://veyro.site/
|
|--------------------------------------------------------------------------
*/

$documentRoot = realpath(
    $_SERVER['DOCUMENT_ROOT'] ?? ''
);

$projectRoot = realpath(
    __DIR__ . '/..'
);

$basePath = '';

if ($documentRoot && $projectRoot) {

    $documentRoot = str_replace(
        '\\',
        '/',
        $documentRoot
    );

    $projectRoot = str_replace(
        '\\',
        '/',
        $projectRoot
    );

    if (
        strpos(
            $projectRoot,
            $documentRoot
        ) === 0
    ) {

        $relativePath = substr(
            $projectRoot,
            strlen($documentRoot)
        );

        $basePath = rtrim(
            $relativePath,
            '/'
        );
    }
}


/*
|--------------------------------------------------------------------------
| Profile Image
|--------------------------------------------------------------------------
*/
$profileImage = $basePath . "/public/images/profile.png";

?>

<header class="site-header">

    <div class="container header-container">

        <!-- LOGO -->
        <a
            href="<?= $basePath ?>/index.php#home"
            class="logo"
        >

            <span class="logo-icon">⚙</span>

            <span class="logo-text">
                VEYRO
            </span>

        </a>


        <!-- NAVIGATION -->
        <nav class="main-nav">

                <a
                    href="<?= $basePath ?>/index.php#home"
                    data-section="home"
                >
                    Home
                </a>

                <a
                    href="<?= $basePath ?>/index.php#services"
                    data-section="services"
                >
                    Services
                </a>

                <a
                    href="<?= $basePath ?>/index.php#packages"
                    data-section="packages"
                >
                    Packages
                </a>

                <a
                    href="<?= $basePath ?>/index.php#offers"
                    data-section="offers"
                >
                    Offers
                </a>

                <a
                    href="<?= $basePath ?>/index.php#contact"
                    data-section="contact"
                >
                    Contact
                </a>

            </nav>


        <!-- AUTHENTICATION -->
        <div class="auth-buttons">

            <?php if ($isLoggedIn): ?>

                <!-- Dashboard -->
                <a
                    href="<?= $basePath ?>/dashboard/dashboard.php"
                    class="dashboard-btn"
                >
                    Dashboard
                </a>


                <!-- PROFILE DROPDOWN -->
                <div class="profile-dropdown">

                    <button
                        type="button"
                        class="profile-avatar profile-dropdown-toggle"
                        title="Profile menu"
                        aria-label="Open profile menu"
                    >

                        <img
                            src="<?= htmlspecialchars($profileImage) ?>"
                            alt="Profile"
                        >

                    </button>


                    <div class="profile-dropdown-menu">

                        <!-- Profile -->
                        <a
                            href="<?= $basePath ?>/dashboard/dashboard.php?page=profile"
                        >
                            Profile
                        </a>


                        <!-- Dashboard -->
                        <a
                            href="<?= $basePath ?>/dashboard/dashboard.php"
                        >
                            Dashboard
                        </a>


                        <!-- ROLE 2: SERVICE ASSISTANT -->
                        <?php if ($userRole === 2): ?>

                            <a
                                href="<?= $basePath ?>/dashboard/dashboard.php?page=appointments"
                            >
                                My Appointments
                            </a>

                        <?php elseif($userRole === 3):?>
                            <a
                                href="<?= $basePath ?>/dashboard/dashboard.php?page=operations"
                            >
                                Monitor Operations
                            </a>
                        <!-- OTHER USERS -->
                        <?php else: ?>

                            <a
                                href="<?= $basePath ?>/dashboard/dashboard.php?page=bookings"
                            >
                                My Bookings
                            </a>

                        <?php endif; ?>


                        <div class="dropdown-divider"></div>


                        <!-- Logout -->
                        <a
                            href="<?= $basePath ?>/login/logout.php"
                            class="logout-link"
                        >
                            Logout
                        </a>

                    </div>

                </div>


            <?php else: ?>

                <!-- NOT LOGGED IN -->

                <a
                    href="<?= $basePath ?>/login/login-form.php"
                    class="login-btn"
                >
                    Login
                </a>


                <a
                    href="<?= $basePath ?>/register/register-form.php"
                    class="register-btn"
                >
                    Register
                </a>

            <?php endif; ?>

        </div>

    </div>

</header>


<script
    src="<?= $basePath ?>/includes/js/profile-dropdown.js"
></script>
<script
    src="<?= $basePath ?>/includes/js/smooth-scroll.js"
></script>
